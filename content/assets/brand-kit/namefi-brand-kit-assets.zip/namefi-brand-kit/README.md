# Namefi Brand Kit

This package contains Namefi logo and motion assets for approved references, editorial use, partnership materials, and product integrations.

## Included Assets

- `assets/namefi-logotype.svg` - primary green Namefi logotype.
- `assets/namefi-logotype-mono.svg` - single-color source logotype.
- `assets/namefi-logotype-mono-green.svg` - green mono logotype.
- `assets/namefi-logotype-mono-ink.svg` - dark ink mono logotype.
- `assets/namefi-logotype-mono-white.svg` - white mono logotype.
- `assets/namefi-compact.svg` - compact mark exported from the first frame of the Namefi Lottie asset.
- `assets/namefi-compact-mono.svg` - single-color source compact mark.
- `assets/namefi-compact-white.svg` - white compact mono mark.
- `assets/namefi-compact-black.svg` - black compact mono mark.
- `assets/namefi-lottie-wordmark.svg` - final-frame wordmark exported from the Namefi Lottie asset.
- `assets/namefi-lottie-wordmark-mono.svg` - single-color final-frame wordmark.
- `assets/namefi_to_nfi.json` - animated Lottie mark that expands from compact mark to wordmark.

## Name Usage

Spell the brand name as `Namefi` in running text. Do not write `NameFi` or `NameFI`. Use `NAMEFI` only where full capitalization is required.

## Trademark And Usage Notice

The Namefi name, logos, marks, visual identity, and related brand assets are trademarks or trade dress of Namefi or its affiliates. Namefi reserves all rights in and to these assets.

Use of these assets is subject to ordinary trademark practice and any written brand or partner guidelines provided by Namefi. Do not use the assets in a way that suggests sponsorship, endorsement, affiliation, or approval by Namefi unless you have written permission.

Do not alter, distort, recolor, outline, animate, combine, or place the marks in a way that could confuse users or weaken the distinctiveness of the Namefi brand. Use mono-color variants only where a single-color mark is needed for contrast, production, or partner-lockup constraints.

This package does not grant ownership rights, trademark rights, or any license beyond the limited permission to use the included assets in accordance with applicable Namefi brand guidance and trademark law.
